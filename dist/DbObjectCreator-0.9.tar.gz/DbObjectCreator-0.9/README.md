# Database Object Creator (D.O.C.)
This library provides a method of creating database connector objects for quick and easy access to multiple
databases (both types and servers).

---

#### DBObjectCreator Setup
This repo can be installed in a python 3 environment with the following command

`pip install git+https:github.com/BridgeCr/davinci`

This library supports both Windows and OSX architecture. If installing on OSX you will need FreeTDS installed.
