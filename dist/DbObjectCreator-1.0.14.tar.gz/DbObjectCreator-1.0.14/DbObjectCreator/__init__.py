"""
DbObjectCreator.

A Database connector object library
"""

__version__ = "1.0.14"
__author__ = 'Gary Haag'
