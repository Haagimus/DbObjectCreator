"""
DbObjectCreator.

A Database connector object library
"""

__version__ = "1.0.12"
__author__ = 'Gary Haag'
